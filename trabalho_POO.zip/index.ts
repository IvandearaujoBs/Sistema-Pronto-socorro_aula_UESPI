import { menuPrincipal } from "./menus/menuPrincipal";

menuPrincipal();
