import { CorRisco } from "../tipos/CorRisco";

export const temposMaximos: Record<CorRisco, number> = {
    vermelho: 0,
    laranja: 30,
    amarelo: 50,
};
