export type CorRisco = "vermelho" | "laranja" | "amarelo";
